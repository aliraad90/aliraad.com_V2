const express = require('express');

const router = express.Router();

// Public: basic info
router.get('/info', (req, res) => {
  res.json({
    name: "Personal Website API",
    version: "1.0.0",
    description: "Backend API for personal website",
    endpoints: {
      health: "/api/status/health",
      contact: "/api/companies/contact",
      auth: "/api/auth/*"
    }
  });
});

module.exports = router;